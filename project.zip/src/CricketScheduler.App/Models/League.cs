namespace CricketScheduler.App.Models;

public sealed class League
{
    public required string Name { get; init; }
    public required Tournament Tournament { get; init; }
    public List<Division> Divisions { get; set; } = [];
    public List<SchedulingRequest> Constraints { get; set; } = [];
    public List<Match> Matches { get; set; } = [];
}
